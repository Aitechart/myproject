<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <?php include 'include/header.php'; ?>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>
<!--Insert body-->
	<main class="app-content">
		<h3>View Packages</h3>
		<hr>
	<div class="tile-body">
	<div class="bg-white py-2 shadow mb-5 bg-white rounded">
		<table class="table table-striped" style="width: 1000px; margin: 30px auto;" align="center">
		  <tr>
			<th width="100px" height="50px">IMAGE:</th>
			<th width="100px" height="50px">Product NO:</th>
			<th width="100px" height="50px">Price:</th>
			<th width="100px" height="50px">Action:</th>
		  </tr>
				<?php
				error_reporting(1);
				include("connection.php");

				if (isset($_GET['del'])) {
				  $del_image = $_GET['del'];

				  // Perform the delete operation
				  $delete_query = "DELETE FROM item WHERE img = '$del_image'";
				  $delete_result = mysql_query($delete_query, $con);

				  if ($delete_result) {
					echo '<div class="alert alert-success" role="alert">Product deleted successfully!</div>';
				  } else {
					echo "Failed to delete the product: " . mysql_error($con);
				  }
				}

				$sel = mysql_query("SELECT * FROM item", $con);
				while ($row = mysql_fetch_array($sel)) {
				  $image = $row['img'];
				  $prodno = $row['prod_no'];
				  $prices = $row['price'];

		?>
			<tr>
			  <td width="100px" height="100px"><img src="image/<?php echo $image; ?>" style="width: 50%; height: 100%;" alt="Product Image"></td>
			  <td width="100px" height="100px" style="vertical-align: middle;"><?php echo $prodno; ?></td>
			  <td width="100px" height="100px" style="vertical-align: middle;"><?php echo $prices; ?></td>
			  <td width="100px" height="100px" style="vertical-align: middle;">
				<a href="view-product.php?del=<?php echo $image; ?>">
				  <button class="btn btn-danger" type="button">Delete</button>
				</a>
			  </td>
			</tr>
		  <?php
		  }
		  ?>
		</table>
	</div>
	</div>

			<div class="clear"></div>
	</main>	
		<!-- Footer -->
        <footer class="app-footer" style="background-color: #910909; color: #FFF" height="50px">
            <div class="col-md-8 text-md-right">
                All rights reserved &copy; <?php echo date('Y'); ?> <p>ADVENTURE</p>
            </div>
        </footer>
	<?php }  ?>
         
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    
</body>
</html>
