<footer class="">
		<div class="container">
			
			<div class="footer-bottom">
				<div class="row">
					
					<div class="col-md-8 text-md-right">
						<div class="copyright">Copyright &copy; 2023 Adventure</div>
					</div>
				</div>
			</div>
		</div>
	</footer>