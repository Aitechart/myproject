<aside class="app-sidebar">
     
      <ul class="app-menu">
        <li><a class="app-menu__item" href="dashboard.php"><i class="app-menu__icon fa fa-dashboard fa-lg"></i><span class="app-menu__label mx-2">Dashboard</span></a></li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-users" aria-hidden="true"></i><span class="app-menu__label">Users</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="register-user.php"><i class="icon fa fa-circle-o mx-4"></i>View Users</a></li>
<!--             <li><a class="treeview-item" href="widgets.html"><i class="icon fa fa-circle"></i> Manage Product</a></li>
 -->          </ul>
        </li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-shopping-bag"></i><span class="app-menu__label">Orders</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="view-order.php"><i class="icon fa fa-circle-o mx-4"></i> View Orders</a></li>
<!--             <li><a class="treeview-item" href="widgets.html"><i class="icon fa fa-circle-o"></i> Manage Order</a></li>
 -->          </ul>
        </li>     
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Packages</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="insert.php"><i class="icon fa fa-circle-o mx-4"></i>Add Package</a></li>
            <li><a class="treeview-item" href="view-product.php"><i class="icon fa fa-circle-o mx-4"></i>View Packages</a></li>
          </ul>
        </li>
		<li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-envelope"></i><span class="app-menu__label">Feedbacks</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="view-feedback.php"><i class="icon fa fa-circle-o mx-4"></i> View Feedbacks</a></li>
<!--             <li><a class="treeview-item" href="widgets.html"><i class="icon fa fa-circle-o"></i> Manage Order</a></li>
 -->          </ul>
        </li>

<!--
 <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Booking History</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="new-bookings.php"><i class="icon fa fa-circle-o"></i>New</a></li>
            <li><a class="treeview-item" href="partial-payment-bookings.php"><i class="icon fa fa-circle-o"></i> Partial Payment </a></li>
            <li><a class="treeview-item" href="full-payment-bookings.php"><i class="icon fa fa-circle-o"></i> Full Payment </a></li>
            <li><a class="treeview-item" href="booking-history.php"><i class="icon fa fa-circle-o"></i> All</a></li>
          </ul>
        </li>

        
     

          <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Report</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="report-booking.php"><i class="icon fa fa-circle-o"></i>Booking Report</a></li>
            <li><a class="treeview-item" href="report-registration.php"><i class="icon fa fa-circle-o"></i>Registration Report</a></li>
          </ul>
        </li> -->
      </ul>
    </aside>