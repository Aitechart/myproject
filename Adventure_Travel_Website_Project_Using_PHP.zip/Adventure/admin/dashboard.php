<?php
error_reporting(1);
session_start();
if ($_SESSION['sid'] == "") {
    header('location:index.php');
} else {
    include("connection.php");

    // Get total orders count
    $order_count = mysql_query("SELECT COUNT(*) AS total_orders FROM orders", $con);
    $order_row = mysql_fetch_assoc($order_count);
    $total_orders = $order_row['total_orders'];
	// Get total products count
    $product_count = mysql_query("SELECT COUNT(*) AS total_products FROM item", $con);
    $product_row = mysql_fetch_assoc($product_count);
    $total_products = $product_row['total_products'];

    // Get total users count
    $user_count = mysql_query("SELECT COUNT(*) AS total_users FROM register", $con);
    $user_row = mysql_fetch_assoc($user_count);
    $total_users = $user_row['total_users'];

    // Get total feedback count
    $feedback_count = mysql_query("SELECT COUNT(*) AS total_feedback FROM content", $con);
    $feedback_row = mysql_fetch_assoc($feedback_count);
    $total_feedback = $feedback_row['total_feedback'];
?>

<html lang="en">
<head>
<title>Admin | Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <?php include 'include/header.php'; ?>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
        </ul>
      </div>
      <div class="row">
          
        <div class="col-md-6 col-lg-6">

                <a href="view-order.php">  
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-shopping-bag fa-3x"></i>
            <div class="info">
              <h4>Orders</h4>
            </div>
			<div class="info m-2" align="right">
              <p><b><?php echo $total_orders; ?></b></p>
			</div>
          </div></a>
        </div>
		
		<div class="col-md-6 col-lg-6">

			<a href="view-product.php">  
          <div class="widget-small info coloured-icon"><i class="icon fa fa-th-list fa-3x"></i>
            <div class="info">
              <h4>Packages</h4>
            </div>
			<div class="info m-2" align="right">
              <p><b><?php echo $total_products; ?></b></p>
			</div>
          </div></a>
        </div>
		
		<div class="col-md-6 col-lg-6">

			<a href="register-user.php">  
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
              <h4>Users</h4>
            </div>
			<div class="info m-2" align="right">
              <p><b><?php echo $total_users; ?></b></p>
			</div>
          </div></a>
        </div>
		
		<div class="col-md-6 col-lg-6">

			<a href="view-feedback.php">  
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-envelope fa-3x"></i>
            <div class="info">
              <h4>Feedback</h4>
            </div>
			<div class="info m-2" align="right">
              <p><b><?php echo $total_feedback; ?></b></p>
			</div>
          </div></a>
        </div>
   
      </div>
     
    </main>
		<!-- Footer -->
        <footer class="app-footer" style="background-color: #910909; color: #FFF" height="50px">
            <div class="col-md-8 text-md-right">
                All rights reserved &copy; <?php echo date('Y'); ?> <p>ADVENTURE</p>
            </div>
        </footer>
	
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    
  </body>
</html>
<?php } ?>

