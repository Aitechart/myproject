<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin | Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <?php include 'include/header.php'; ?>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>
<!--Insert body-->
	<main class="app-content">
		<h3>View Users</h3>
		<hr>
	<div class="tile-body">
	<div class="bg-white py-2 shadow mb-5 bg-white rounded">
		<table class="table table-striped" style="width: 1000px; margin: 30px auto;" align="center">
		  <tr>
			<th width="30px" height="50px">ID:</th>
			<th width="100px" height="50px">Name:</th>
			<th width="100px" height="50px">Email:</th>
			<th width="100px" height="50px">Password:</th>
			<th width="100px" height="50px">Phone:</th>
			<th width="100px" height="50px">City:</th>
			<th width="100px" height="50px">Township:</th>
			<th width="100px" height="50px">Action:</th>
		  </tr>
		  <?php
				error_reporting(1);
				include("connection.php");

				if (isset($_GET['del'])) {
				  $del_id = $_GET['del'];
				  
				  // Perform the delete operation
				  $delete_query = "DELETE FROM register WHERE reg_id = '$del_id'";
				  $delete_result = mysql_query($delete_query, $con);
				  
				  if ($delete_result) {
					echo '<div class="alert alert-success" role="alert">User deleted successfully!</div>';
				  } else {
					echo'<div class="alert alert-danger" role="alert">Filed to delete the user!</div>' . mysql_error($con);
				  }
				}

				$sel = mysql_query("SELECT * FROM register", $con);
				while ($row = mysql_fetch_array($sel)) {
				  $id = $row['reg_id'];
				  $regname = $row['name'];
				  $mail = $row['email'];
				  $pwd = $row['password'];
				  $ph = $row['phone'];
				  $cityn = $row['city'];
				  $town = $row['township'];
		?>
			<tr>
			  <td width="30px" height="50px" style="vertical-align: middle;"><?php echo $id; ?></td>
			  <td width="100px" height="50px" style="vertical-align: middle;"><?php echo $regname; ?></td>
			  <td width="100px" height="50px" style="vertical-align: middle;"><?php echo $mail; ?></td>
			  <td width="100px" height="50px" style="vertical-align: middle;"><?php echo $pwd; ?></td>
			  <td width="100px" height="50px" style="vertical-align: middle;"><?php echo $ph; ?></td>
			  <td width="100px" height="50px" style="vertical-align: middle;"><?php echo $cityn; ?></td>
			  <td width="100px" height="50px" style="vertical-align: middle;"><?php echo $town; ?></td>
			  <td width="100px" height="50px" style="vertical-align: middle;">
				<a href="register-user.php?del=<?php echo $id; ?>">
				  <button class="btn btn-danger" type="button">Delete</button>
				</a>
			  </td>
			</tr>
		  <?php
		  }
		  ?>
		</table>
	</div>
	</div>

			<div class="clear"></div>
	</main>	
		<!-- Footer -->
        <footer class="app-footer" style="background-color: #910909; color: #FFF" height="50px">
            <div class="col-md-8 text-md-right">
                All rights reserved &copy; <?php echo date('Y'); ?> <p>ADVENTURE</p>
            </div>
        </footer>
	<?php }  ?>

         
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    
</body>
</html>
