<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<?php
error_reporting(1);
include("connection.php");
$img=$_FILES['img']['name'];
$prono=$_POST['t1'];
$price=$_POST['t2'];
if($_POST['sub'])
{$qry="INSERT INTO item(img,prod_no,price)VALUES('$img','$prono','$price')";
$result=mysql_query($qry) or die ("save items query fail.");
if($result)			
	   {mkdir("image/$i");
			move_uploaded_file($_FILES['img']['tmp_name'],"image/$i".$_FILES['img']['name']);	
  // move_uploaded_file($_FILES['file']['tmp_name'],"itempics/$itemno.jpg");
		
	    $err = '<div class="alert alert-success" role="alert">Item inserted successfully!</div>';
	
		}
	else
	 {
	   echo "item is not inserted";
	   }
	}  
	mysql_close($con);
?>
<html lang="en">
<head>
<title>Admin | Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <?php include 'include/header.php'; ?>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>
<!--Insert body-->
<main class="app-content">
	<h3>Add Package</h3>
	<hr>
	<div class="tile"> 
		<div class="tile-body">
			 <div id="contact_form" class="col_2 d-flex justify-content-left px-3">
                
				<form  name="testform" method="post" enctype="multipart/form-data" >
			<table>
				 <tr>
					<td height="20px"></td>
				</tr>	
				<tr>
				<td><span class="style3">Image:</span></td>
				<td class="px-3">
					<input class="form-control-file" name="img" type="file">
				</td>
				</tr>
				 <tr>
						<td height="20px"></td>
				</tr>			
				
				<tr>
				  <td><span class="style3">product name: </span></td>
				  <td class="px-3">
				  <label>
					<input class="form-control" name="t1" type="text" id="t1">
				  </label>
				  </td>
				</tr>
				 <tr>
						<td height="20px"></td>
				</tr>			
				
				<tr>
				  <td><span class="style3">Price:</span></td>
				  <td class="px-3"><label>
					<input class="form-control" name="t2" type="text" id="t2">
				  </label></td>
				</tr>
				 <tr>
						<td height="20px"></td>
				</tr>			
				
				<tr>
				<td  colspan="2" align="left">
					<input name="sub" type="submit" value="Submit">
					
				</td>
				</tr>
				
			</table><br>
			</form>
				<h4><?php echo $err;?></h4>
            </div> 
       
        
        

			<div class="clear"></div>
		</div>
	</div>
	
       <div class="row">
        <div class="col-md-12">
          <div class="tile">
			<div class="tile-body">
			  <table class="table table-hover table-bordered" id="sampleTable">
				<thead>
				  <tr>
					<th>Sr.No</th>
					<th>Name</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>
				  <?php
				  error_reporting(1);
				  include("connection.php");

				  if (isset($_GET['del'])) {
					$del_product = $_GET['del'];

					// Perform the delete operation
					$delete_query = "DELETE FROM item WHERE prod_no = '$del_product'";
					$delete_result = mysql_query($delete_query, $con);

					if ($delete_result) {
					  echo '<div class="alert alert-success" role="alert">Product deleted successfully!</div>';
					} else {
					  echo '<div class="alert alert-warning" role="alert">Failed to delete the product</div>' . mysql_error($con);
					}
				  }

				  $sel = mysql_query("SELECT * FROM item", $con);
				  $cnt = 1;

				  while ($row = mysql_fetch_array($sel)) {
					$prono = $row['prod_no'];
				  ?>
					<tr>
					  <td style="vertical-align: middle;"><?php echo $cnt; ?></td>
					  <td style="vertical-align: middle;"><?php echo htmlentities($row['prod_no']); ?></td>
					  <td style="vertical-align: middle;">
						<a href="?del=<?php echo htmlentities($row['prod_no']); ?>">
						  <button class="btn btn-danger" type="button">Delete</button>
						</a>
					  </td>
					</tr>
				  <?php
					$cnt++;
				  }
				  ?>
				</tbody>
			  </table>
			</div>

          </div>
        </div>
      </div>
	
	</main>
		<!-- Footer -->
        <footer class="app-footer" style="background-color: #910909; color: #FFF" height="50px">
            <div class="col-md-8 text-md-right">
                All rights reserved &copy; <?php echo date('Y'); ?> <p>ADVENTURE</p>
            </div>
        </footer>
	
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    
  </body>
</html>
<?php } ?>